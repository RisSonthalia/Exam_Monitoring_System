<?php
//all the variables defined here are accessible in all the files that include this one

$servername = "localhost";
$username = "root";
$password = "";
$database = "online_exam_system";
$con = mysqli_connect($servername, $username, $password, $database);

// Check if the connection was successful
if ($con === false) {
    die("Error: Connection failed. " . mysqli_connect_error());
}
